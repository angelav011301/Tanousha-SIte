
=== LONDINIA REGULAR ===
=== LONDINIA ITALIC ===

=== LONDINIA MEDIUM ===
=== LONDINIA MEDIUM ITALIC ===

=== LONDINIA BOLD ===
=== LONDINIA BOLD ITALIC ===

Keith Bates / K-Type © 2016 (version 1.1)
www.k-type.com    -    info@k-type.com

LONDINIA is a contemporary Roman typeface with clear, open shapes, a generous x-height, and streamlined serifs. The typeface includes small serif-shaped cutaways and subtle incisions that give a lift to congested corners.

Each of the three weights of Londinia is accompanied by a complimentary italic.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------